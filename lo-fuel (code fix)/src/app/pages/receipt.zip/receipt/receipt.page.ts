import { ActivatedRoute } from "@angular/router";
import { Component, OnInit } from "@angular/core";
import { NavController } from "@ionic/angular";

@Component({
  selector: "app-receipt",
  templateUrl: "./receipt.page.html",
  styleUrls: ["./receipt.page.scss"],
})
export class ReceiptPage implements OnInit {
  rate = 3;
  status: any;
  constructor(private route: ActivatedRoute, private nav: NavController) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.status = params["id"];
    });
  }
  history() {
    this.nav.navigateForward("/history");
  }
  trackOrder() {
    this.nav.navigateForward("/track");
  }
}
